package router

import (
	"database/sql"
	"finalfinal/hotel-service/handler"
	"github.com/gorilla/mux"
)

func NewRouter(db *sql.DB) *mux.Router {
	router := mux.NewRouter()
	router.HandleFunc("/rooms", handler.GetRooms(db)).Methods("GET")
	router.HandleFunc("/rooms/{id}", handler.GetRoom(db)).Methods("GET")
	router.HandleFunc("/rooms", handler.CreateRoom(db)).Methods("POST")
	router.HandleFunc("/rooms/{id}", handler.UpdateRoom(db)).Methods("PUT")
	router.HandleFunc("/rooms/{id}", handler.DeleteRoom(db)).Methods("DELETE")
	return router
}
