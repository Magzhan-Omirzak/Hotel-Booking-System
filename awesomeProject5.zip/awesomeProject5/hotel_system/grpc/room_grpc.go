package grpc

import (
	"context"
	"hotel_system/models"
	pb "hotel_system/proto" // Импортируем сгенерированные файлы gRPC
	"hotel_system/services"
	"hotel_system/utils"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type RoomServiceServer struct {
	roomService *services.RoomService
	pb.UnimplementedRoomServiceServer
}

func (s *RoomServiceServer) CreateRoom(ctx context.Context, req *pb.Room) (*pb.Room, error) {
	room := models.Room{
		Number:       req.Number,
		Type:         req.Type,
		Price:        req.Price,
		Availability: req.Availability,
	}

	err := s.roomService.CreateRoom(&room)
	if err != nil {
		utils.Logger.Error("Failed to create room: ", err)
		return nil, status.Errorf(codes.Internal, "failed to create room: %v", err)
	}

	return &pb.Room{
		Id:           uint32(room.ID),
		Number:       room.Number,
		Type:         room.Type,
		Price:        room.Price,
		Availability: room.Availability,
	}, nil
}

func (s *RoomServiceServer) GetRoom(ctx context.Context, req *pb.RoomID) (*pb.Room, error) {
	room, err := s.roomService.GetRoom(uint(req.Id))
	if err != nil {
		utils.Logger.Error("Failed to get room: ", err)
		return nil, status.Errorf(codes.NotFound, "room not found: %v", err)
	}

	return &pb.Room{
		Id:           uint32(room.ID),
		Number:       room.Number,
		Type:         room.Type,
		Price:        room.Price,
		Availability: room.Availability,
	}, nil
}

func (s *RoomServiceServer) UpdateRoom(ctx context.Context, req *pb.Room) (*pb.Room, error) {
	room, err := s.roomService.GetRoom(uint(req.Id))
	if err != nil {
		utils.Logger.Error("Failed to get room: ", err)
		return nil, status.Errorf(codes.NotFound, "room not found: %v", err)
	}

	room.Number = req.Number
	room.Type = req.Type
	room.Price = req.Price
	room.Availability = req.Availability

	err = s.roomService.UpdateRoom(&room)
	if err != nil {
		utils.Logger.Error("Failed to update room: ", err)
		return nil, status.Errorf(codes.Internal, "failed to update room: %v", err)
	}

	return &pb.Room{
		Id:           uint32(room.ID),
		Number:       room.Number,
		Type:         room.Type,
		Price:        room.Price,
		Availability: room.Availability,
	}, nil
}

func (s *RoomServiceServer) DeleteRoom(ctx context.Context, req *pb.RoomID) (*pb.Empty, error) {
	err := s.roomService.DeleteRoom(uint(req.Id))
	if err != nil {
		utils.Logger.Error("Failed to delete room: ", err)
		return nil, status.Errorf(codes.NotFound, "room not found: %v", err)
	}

	return &pb.Empty{}, nil
}

func (s *RoomServiceServer) GetRooms(ctx context.Context, req *pb.RoomQuery) (*pb.RoomList, error) {
	filter := make(map[string]interface{})
	for key, value := range req.Filter {
		filter[key] = value
	}

	rooms, err := s.roomService.GetRooms(filter, req.Sort, int(req.Page), int(req.Size))
	if err != nil {
		utils.Logger.Error("Failed to get rooms: ", err)
		return nil, status.Errorf(codes.Internal, "failed to get rooms: %v", err)
	}

	roomList := &pb.RoomList{}
	for _, room := range rooms {
		roomList.Rooms = append(roomList.Rooms, &pb.Room{
			Id:           uint32(room.ID),
			Number:       room.Number,
			Type:         room.Type,
			Price:        room.Price,
			Availability: room.Availability,
		})
	}

	return roomList, nil
}
