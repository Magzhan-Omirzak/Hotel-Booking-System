package controllers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"hotel_system/models"
	"hotel_system/services"
	"hotel_system/utils"
)

var roomService = services.RoomService{}

func CreateRoom(c *gin.Context) {
	var input models.Room
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := roomService.CreateRoom(&input); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	utils.Logger.Info("Room created: ", input)
	c.JSON(http.StatusCreated, input)
}

func GetRoom(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	room, err := roomService.GetRoom(uint(id))
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Room not found"})
		return
	}

	utils.Logger.Info("Room retrieved: ", room)
	c.JSON(http.StatusOK, room)
}

func UpdateRoom(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	var input models.Room
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	room, err := roomService.GetRoom(uint(id))
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Room not found"})
		return
	}

	room.Number = input.Number
	room.Type = input.Type
	room.Price = input.Price
	room.Availability = input.Availability

	if err := roomService.UpdateRoom(&room); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	utils.Logger.Info("Room updated: ", room)
	c.JSON(http.StatusOK, room)
}

func DeleteRoom(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	if err := roomService.DeleteRoom(uint(id)); err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Room not found"})
		return
	}

	utils.Logger.Info("Room deleted: ", id)
	c.JSON(http.StatusOK, gin.H{"message": "Room deleted"})
}

func GetRooms(c *gin.Context) {
	filter := map[string]interface{}{}
	if availability := c.Query("availability"); availability != "" {
		filter["availability"] = availability == "true"
	}

	sort := c.Query("sort")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "10"))

	rooms, err := roomService.GetRooms(filter, sort, page, size)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	utils.Logger.Info("Rooms retrieved: ", rooms)
	c.JSON(http.StatusOK, rooms)
}
