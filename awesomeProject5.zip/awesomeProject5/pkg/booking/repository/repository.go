// pkg/booking/repository/repository.go
package repository

import (
	"awesomeProject5/internal/entity"
	"database/sql"
)

type BookingRepository struct {
	DB *sql.DB
}

func NewBookingRepository(db *sql.DB) *BookingRepository {
	return &BookingRepository{DB: db}
}

func (repo *BookingRepository) CreateBooking(booking *entity.Booking) error {
	_, err := repo.DB.Exec("INSERT INTO bookings (user_id, hotel_id, check_in, check_out, status) VALUES ($1, $2, $3, $4, $5)", booking.UserID, booking.HotelID, booking.CheckIn, booking.CheckOut, booking.Status)
	return err
}

func (repo *BookingRepository) GetBookings() ([]entity.Booking, error) {
	rows, err := repo.DB.Query("SELECT id, user_id, hotel_id, check_in, check_out, status FROM bookings")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	bookings := []entity.Booking{}
	for rows.Next() {
		var booking entity.Booking
		if err := rows.Scan(&booking.ID, &booking.UserID, &booking.HotelID, &booking.CheckIn, &booking.CheckOut, &booking.Status); err != nil {
			return nil, err
		}
		bookings = append(bookings, booking)
	}
	return bookings, nil
}
