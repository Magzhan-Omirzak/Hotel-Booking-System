package entity

type Payment struct {
	ID          int
	BookingID   int
	Amount      float64
	Status      string
	PaymentDate string
}
