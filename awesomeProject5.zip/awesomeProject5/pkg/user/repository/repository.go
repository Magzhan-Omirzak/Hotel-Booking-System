// pkg/user/repository/repository.go
package repository

import (
	"awesomeProject5/internal/entity"
	"database/sql"
)

type UserRepository struct {
	DB *sql.DB
}

func (repo *UserRepository) GetUsers() ([]entity.User, error) {
	rows, err := repo.DB.Query("SELECT id, name, email FROM users")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	users := []entity.User{}
	for rows.Next() {
		var user entity.User
		if err := rows.Scan(&user.ID, &user.Name, &user.Email); err != nil {
			return nil, err
		}
		users = append(users, user)
	}
	return users, nil
}
