package router

import (
	"github.com/gorilla/mux"
	"room-service/handler"
)

func NewRouter(h *handler.Handler) *mux.Router {
	r := mux.NewRouter()

	r.HandleFunc("/rooms", h.CreateRoom).Methods("POST")
	r.HandleFunc("/rooms", h.GetRooms).Methods("GET")
	r.HandleFunc("/rooms/{id}", h.GetRoom).Methods("GET")
	r.HandleFunc("/rooms/{id}", h.UpdateRoom).Methods("PUT")
	r.HandleFunc("/rooms/{id}", h.DeleteRoom).Methods("DELETE")

	return r
}
