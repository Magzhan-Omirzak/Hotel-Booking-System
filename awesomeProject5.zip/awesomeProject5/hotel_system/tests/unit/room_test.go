package unit

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"hotel_system/models"
	"hotel_system/services"
)

func TestCreateRoom(t *testing.T) {
	roomService := services.RoomService{}
	room := models.Room{
		Number:       "101",
		Type:         "Single",
		Price:        100.0,
		Availability: true,
	}

	err := roomService.CreateRoom(&room)
	assert.NoError(t, err)
}

func TestGetRoom(t *testing.T) {
	roomService := services.RoomService{}
	room, err := roomService.GetRoom(1)

	assert.NoError(t, err)
	assert.Equal(t, "101", room.Number)
}

func TestUpdateRoom(t *testing.T) {
	roomService := services.RoomService{}
	room, _ := roomService.GetRoom(1)

	room.Price = 120.0
	err := roomService.UpdateRoom(&room)
	assert.NoError(t, err)
}
