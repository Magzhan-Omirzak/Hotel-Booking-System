// pkg/api-gateway/router/router.go
package router

import (
	"awesomeProject5/pkg/api-gateway/handler"
	"github.com/gorilla/mux"
)

func SetupRoutes(r *mux.Router) {
	authServiceURL := "http://localhost:8081"
	bookingServiceURL := "http://localhost:8082"
	hotelServiceURL := "http://localhost:8083"

	r.HandleFunc("/register", handler.Proxy(authServiceURL)).Methods("POST")
	r.HandleFunc("/login", handler.Proxy(authServiceURL)).Methods("POST")
	r.HandleFunc("/book", handler.Proxy(bookingServiceURL)).Methods("POST")
	r.HandleFunc("/bookings", handler.Proxy(bookingServiceURL)).Methods("GET")
	r.HandleFunc("/hotels", handler.Proxy(hotelServiceURL)).Methods("GET")
	r.HandleFunc("/hotels", handler.Proxy(hotelServiceURL)).Methods("POST")
	r.HandleFunc("/bookings", handler.Proxy(hotelServiceURL)).Methods("GET")
	r.HandleFunc("/bookings/{id}", handler.Proxy(hotelServiceURL)).Methods("PUT")
}
