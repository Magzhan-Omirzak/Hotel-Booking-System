// js/scripts.js
document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("register-form");
    const loginForm = document.getElementById("login-form");
    const bookingForm = document.getElementById("booking-form");
    const viewBookingsButton = document.getElementById("view-bookings");
    const hotelList = document.getElementById("hotel-list");
    const bookingsList = document.getElementById("bookings-list");

    const apiUrl = "http://localhost:8080";

    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = document.getElementById("register-name").value;
        const email = document.getElementById("register-email").value;
        const password = document.getElementById("register-password").value;

        try {
            const response = await fetch(`${apiUrl}/register`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, email, password })
            });
            if (response.ok) {
                alert("Registered successfully!");
            } else {
                alert("Registration failed!");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    });

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = document.getElementById("login-email").value;
        const password = document.getElementById("login-password").value;

        try {
            const response = await fetch(`${apiUrl}/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });
            if (response.ok) {
                const data = await response.json();
                localStorage.setItem("token", data.token);
                document.getElementById("auth").style.display = "none";
                document.getElementById("booking").style.display = "block";
                if (email === "admin@example.com") {
                    document.getElementById("admin").style.display = "block";
                }
                loadHotels();
            } else {
                alert("Login failed!");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    });

    bookingForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const hotelId = hotelList.value;
        const checkIn = document.getElementById("check-in").value;
        const checkOut = document.getElementById("check-out").value;
        const token = localStorage.getItem("token");

        try {
            const response = await fetch(`${apiUrl}/book`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({ hotel_id: hotelId, check_in: checkIn, check_out: checkOut })
            });
            if (response.ok) {
                alert("Room booked successfully!");
            } else {
                alert("Booking failed!");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    });

    viewBookingsButton.addEventListener("click", async () => {
        const token = localStorage.getItem("token");

        try {
            const response = await fetch(`${apiUrl}/bookings`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            });
            if (response.ok) {
                const bookings = await response.json();
                bookingsList.innerHTML = "";
                bookings.forEach(booking => {
                    const bookingItem = document.createElement("div");
                    bookingItem.textContent = `Booking ID: ${booking.id}, User ID: ${booking.user_id}, Hotel ID: ${booking.hotel_id}, Check-in: ${booking.check_in}, Check-out: ${booking.check_out}, Status: ${booking.status}`;
                    bookingsList.appendChild(bookingItem);
                });
            } else {
                alert("Failed to load bookings!");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    });

    async function loadHotels() {
        try {
            const response = await fetch(`${apiUrl}/hotels`, {
                method: "GET",
                headers: { "Content-Type": "application/json" }
            });
            if (response.ok) {
                const hotels = await response.json();
                hotels.forEach(hotel => {
                    const option = document.createElement("option");
                    option.value = hotel.id;
                    option.textContent = hotel.name;
                    hotelList.appendChild(option);
                });
            } else {
                alert("Failed to load hotels!");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    }
});
