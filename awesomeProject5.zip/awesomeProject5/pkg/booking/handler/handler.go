// pkg/booking/handler/handler.go
package handler

import (
	"awesomeProject5/internal/entity"
	"awesomeProject5/pkg/booking/repository"
	"database/sql"
	"encoding/json"
	"net/http"
)

type Handler struct {
	db *sql.DB
}

func NewHandler(db *sql.DB) *Handler {
	return &Handler{db: db}
}

func (h *Handler) CreateBooking(w http.ResponseWriter, r *http.Request) {
	var booking entity.Booking
	err := json.NewDecoder(r.Body).Decode(&booking)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	repo := repository.NewBookingRepository(h.db)
	err = repo.CreateBooking(&booking)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) GetBookings(w http.ResponseWriter, r *http.Request) {
	repo := repository.NewBookingRepository(h.db)
	bookings, err := repo.GetBookings()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(bookings)
}
