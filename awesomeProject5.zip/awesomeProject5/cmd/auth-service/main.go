package main

import (
	"awesomeProject5/pkg/auth/config"
	"awesomeProject5/pkg/auth/handler"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func main() {
	r := mux.NewRouter()
	db := config.ConnectDB()
	authHandler := handler.NewHandler(db)

	r.HandleFunc("/register", authHandler.Register).Methods("POST")
	r.HandleFunc("/login", authHandler.Login).Methods("POST")

	log.Println("Auth Service is running on port 8081")
	http.ListenAndServe(":8081", r)
}
