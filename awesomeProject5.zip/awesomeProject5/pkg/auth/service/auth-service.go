package service

import (
	"database/sql"
)

func AuthenticateUser(db *sql.DB, username, password string) (bool, error) {
	var id int
	query := "SELECT id FROM users WHERE username=$1 AND password=$2"
	err := db.QueryRow(query, username, password).Scan(&id)
	if err != nil {
		if err == sql.ErrNoRows {
			return false, nil // Пользователь не найден
		}
		return false, err
	}
	return true, nil
}

func RegisterUser(db *sql.DB, username, password, email string) error {
	query := "INSERT INTO users (username, password, email) VALUES ($1, $2, $3)"
	_, err := db.Exec(query, username, password, email)
	if err != nil {
		return err
	}
	return nil
}
