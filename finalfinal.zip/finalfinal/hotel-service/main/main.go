package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"
	_ "github.com/lib/pq"
)

var db *sql.DB

func main() {
	var err error

	dbHost := os.Getenv("DB_HOST")
	dbPort := os.Getenv("DB_PORT")
	dbUser := os.Getenv("DB_USER")
	dbPassword := os.Getenv("DB_PASSWORD")
	dbName := os.Getenv("DB_NAME")

	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		dbHost, dbPort, dbUser, dbPassword, dbName)

	db, err = sql.Open("postgres", psqlInfo)
	if err != nil {
		log.Fatalf("Error opening database: %v\n", err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatalf("Error connecting to the database: %v\n", err)
	}

	router := mux.NewRouter()
	router.HandleFunc("/rooms", getRooms).Methods("GET")
	router.HandleFunc("/rooms/{id}", getRoom).Methods("GET")
	router.HandleFunc("/rooms/{id}", updateRoom).Methods("PUT")
	router.HandleFunc("/rooms", createRoom).Methods("POST")
	router.HandleFunc("/rooms/{id}", deleteRoom).Methods("DELETE")

	log.Println("Hotel Service is running on port 8082")
	log.Fatal(http.ListenAndServe(":8082", router))
}

func getRooms(w http.ResponseWriter, r *http.Request) {
	// Implementation of getting all rooms
}

func getRoom(w http.ResponseWriter, r *http.Request) {
	// Implementation of getting a room by ID
}

func updateRoom(w http.ResponseWriter, r *http.Request) {
	// Implementation of updating a room by ID
}

func createRoom(w http.ResponseWriter, r *http.Request) {
	// Implementation of creating a new room
}

func deleteRoom(w http.ResponseWriter, r *http.Request) {
	// Implementation of deleting a room by ID
}
