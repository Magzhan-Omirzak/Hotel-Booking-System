package handler

import (
	"awesomeProject5/internal/entity"
	"awesomeProject5/pkg/hotel/repository"
	"database/sql"
	"encoding/json"
	"github.com/gorilla/mux"
	"log"
	"net/http"
	"strconv"
)

type Handler struct {
	db *sql.DB
}

func NewHandler(db *sql.DB) *Handler {
	return &Handler{db: db}
}

func (h *Handler) GetHotels(w http.ResponseWriter, r *http.Request) {
	repo := repository.NewHotelRepository(h.db)
	hotels, err := repo.GetHotels()
	if err != nil {
		log.Printf("Error getting hotels: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Println("Successfully retrieved hotels")
	json.NewEncoder(w).Encode(hotels)
}

func (h *Handler) CreateHotel(w http.ResponseWriter, r *http.Request) {
	var hotel entity.Hotel
	err := json.NewDecoder(r.Body).Decode(&hotel)
	if err != nil {
		log.Printf("Error decoding hotel: %v", err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	repo := repository.NewHotelRepository(h.db)
	err = repo.CreateHotel(&hotel)
	if err != nil {
		log.Printf("Error creating hotel: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Printf("Hotel %s created successfully", hotel.Name)
	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) GetBookings(w http.ResponseWriter, r *http.Request) {
	repo := repository.NewHotelRepository(h.db)
	bookings, err := repo.GetBookings()
	if err != nil {
		log.Printf("Error getting bookings: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Println("Successfully retrieved bookings")
	json.NewEncoder(w).Encode(bookings)
}

func (h *Handler) UpdateBooking(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, err := strconv.Atoi(vars["id"])
	if err != nil {
		log.Printf("Invalid booking ID: %v", err)
		http.Error(w, "Invalid booking ID", http.StatusBadRequest)
		return
	}

	var booking entity.Booking
	err = json.NewDecoder(r.Body).Decode(&booking)
	if err != nil {
		log.Printf("Error decoding booking: %v", err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	booking.ID = id
	repo := repository.NewHotelRepository(h.db)
	err = repo.UpdateBooking(&booking)
	if err != nil {
		log.Printf("Error updating booking: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Printf("Booking %d updated successfully", booking.ID)
	w.WriteHeader(http.StatusOK)
}
