package main

import (
	_ "finalfinal/auth-service/handler"
	_ "finalfinal/auth-service/router"

	"database/sql"
	"fmt"
	"log"
	"time"

	_ "github.com/lib/pq"
)

func main() {
	var db *sql.DB
	var err error

	// Попытка подключения к базе данных
	for {
		db, err = sql.Open("postgres", "postgres://postgres:654321Aa@db:5432/mydatabase?sslmode=disable")
		if err != nil {
			log.Printf("Ошибка подключения к базе данных: %v", err)
		} else {
			err = db.Ping()
			if err == nil {
				break
			}
			log.Printf("Ошибка пинга базы данных: %v", err)
		}
		log.Println("Повторная попытка через 5 секунд...")
		time.Sleep(5 * time.Second)
	}

	// Ваш основной код сервиса
	fmt.Println("Успешное подключение к базе данных!")
}
