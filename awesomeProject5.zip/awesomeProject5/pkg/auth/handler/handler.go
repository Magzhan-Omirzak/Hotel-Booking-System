package handler

import (
	"awesomeProject5/internal/entity"
	"awesomeProject5/pkg/auth/repository"
	"database/sql"
	"encoding/json"
	"github.com/dgrijalva/jwt-go"
	"log"
	"net/http"
	"time"
)

type Handler struct {
	db *sql.DB
}

func NewHandler(db *sql.DB) *Handler {
	return &Handler{db: db}
}

func (h *Handler) Register(w http.ResponseWriter, r *http.Request) {
	var user entity.User
	err := json.NewDecoder(r.Body).Decode(&user)
	if err != nil {
		log.Printf("Error decoding user: %v", err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	repo := repository.NewUserRepository(h.db)
	err = repo.CreateUser(&user)
	if err != nil {
		log.Printf("Error creating user: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Printf("User %s registered successfully", user.Username)
	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	var creds entity.Credentials
	err := json.NewDecoder(r.Body).Decode(&creds)
	if err != nil {
		log.Printf("Error decoding credentials: %v", err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	repo := repository.NewUserRepository(h.db)
	user, err := repo.Authenticate(&creds)
	if err != nil {
		log.Printf("Error authenticating user: %v", err)
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"username": user.Username,
		"exp":      time.Now().Add(time.Hour * 72).Unix(),
	})

	tokenString, err := token.SignedString([]byte("secret"))
	if err != nil {
		log.Printf("Error signing token: %v", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	log.Printf("User %s logged in successfully", user.Username)
	json.NewEncoder(w).Encode(map[string]string{"token": tokenString})
}
