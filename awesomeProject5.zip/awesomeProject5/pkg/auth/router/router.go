package router

import (
	"awesomeProject5/pkg/auth/handler"
	"database/sql"
	"github.com/gorilla/mux"
)

func SetupRoutes(r *mux.Router, db *sql.DB) {
	h := handler.NewHandler(db)

	r.HandleFunc("/register", h.Register).Methods("POST")
	r.HandleFunc("/login", h.Login).Methods("POST")
}
