// pkg/hotel/repository/repository.go
package repository

import (
	"awesomeProject5/internal/entity"
	"database/sql"
)

type HotelRepository struct {
	DB *sql.DB
}

func NewHotelRepository(db *sql.DB) *HotelRepository {
	return &HotelRepository{DB: db}
}

func (repo *HotelRepository) GetHotels() ([]entity.Hotel, error) {
	rows, err := repo.DB.Query("SELECT id, name, address, rating FROM hotels")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	hotels := []entity.Hotel{}
	for rows.Next() {
		var hotel entity.Hotel
		if err := rows.Scan(&hotel.ID, &hotel.Name, &hotel.Address, &hotel.Rating); err != nil {
			return nil, err
		}
		hotels = append(hotels, hotel)
	}
	return hotels, nil
}

func (repo *HotelRepository) CreateHotel(hotel *entity.Hotel) error {
	_, err := repo.DB.Exec("INSERT INTO hotels (name, address, rating) VALUES ($1, $2, $3)", hotel.Name, hotel.Address, hotel.Rating)
	return err
}

func (repo *HotelRepository) GetBookings() ([]entity.Booking, error) {
	rows, err := repo.DB.Query("SELECT id, user_id, hotel_id, check_in, check_out, status FROM bookings")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	bookings := []entity.Booking{}
	for rows.Next() {
		var booking entity.Booking
		if err := rows.Scan(&booking.ID, &booking.UserID, &booking.HotelID, &booking.CheckIn, &booking.CheckOut, &booking.Status); err != nil {
			return nil, err
		}
		bookings = append(bookings, booking)
	}
	return bookings, nil
}

func (repo *HotelRepository) UpdateBooking(booking *entity.Booking) error {
	_, err := repo.DB.Exec("UPDATE bookings SET user_id = $1, hotel_id = $2, check_in = $3, check_out = $4, status = $5 WHERE id = $6", booking.UserID, booking.HotelID, booking.CheckIn, booking.CheckOut, booking.Status, booking.ID)
	return err
}
