// pkg/booking/router/router.go
package router

import (
	"awesomeProject5/pkg/booking/handler"
	"database/sql"
	"github.com/gorilla/mux"
)

func SetupRoutes(r *mux.Router, db *sql.DB) {
	h := handler.NewHandler(db)
	r.HandleFunc("/book", h.CreateBooking).Methods("POST")
	r.HandleFunc("/bookings", h.GetBookings).Methods("GET")
}
