package main

import (
	"awesomeProject5/pkg/booking/config"
	"awesomeProject5/pkg/booking/router"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func main() {
	r := mux.NewRouter()
	db := config.ConnectDB()
	router.SetupRoutes(r, db)

	log.Println("Booking Service is running on port 8082")
	http.ListenAndServe(":8082", r)
}
