package entity

type Hotel struct {
	ID      int
	Name    string
	Address string
	Rating  float64
}
