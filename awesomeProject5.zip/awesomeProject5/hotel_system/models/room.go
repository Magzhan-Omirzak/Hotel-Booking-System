package models

import "gorm.io/gorm"

type Room struct {
	gorm.Model
	Number       string  `json:"number" gorm:"unique"`
	Type         string  `json:"type"`
	Price        float64 `json:"price"`
	Availability bool    `json:"availability"`
}
