package handler

import (
	"database/sql"
	"github.com/gorilla/sessions"
	_ "github.com/lib/pq"
	"golang.org/x/crypto/bcrypt"
	"html/template"
	"log"
	"net/http"
)

var db *sql.DB
var store = sessions.NewCookieStore([]byte("super-secret-key"))

func InitDB(connStr string) {
	var err error
	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatalf("Error opening database: %v", err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatalf("Error connecting to the database: %v", err)
	}
	log.Println("Connected to the database successfully.")
}

func RegisterHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		email := r.FormValue("email")
		password := r.FormValue("password")

		var userCount int
		err := db.QueryRow("SELECT COUNT(*) FROM users WHERE username = $1", username).Scan(&userCount)
		if err != nil {
			http.Error(w, "Server error, unable to check username.", 500)
			log.Printf("Error checking username existence: %v", err)
			return
		}
		if userCount > 0 {
			http.Error(w, "Username already taken.", 400)
			return
		}

		err = db.QueryRow("SELECT COUNT(*) FROM users WHERE email = $1", email).Scan(&userCount)
		if err != nil {
			http.Error(w, "Server error, unable to check email.", 500)
			log.Printf("Error checking email existence: %v", err)
			return
		}
		if userCount > 0 {
			http.Error(w, "Email already taken.", 400)
			return
		}

		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
		if err != nil {
			http.Error(w, "Server error, unable to create your account.", 500)
			log.Printf("Error hashing password: %v", err)
			return
		}

		_, err = db.Exec("INSERT INTO users (username, email, password) VALUES ($1, $2, $3)", username, email, hashedPassword)
		if err != nil {
			http.Error(w, "Server error, unable to create your account.", 500)
			log.Printf("Error inserting user: %v", err)
			return
		}

		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	tmpl, err := template.ParseFiles("web/register.html")
	if err != nil {
		http.Error(w, "Server error, unable to load page.", 500)
		log.Printf("Error parsing template: %v", err)
		return
	}
	tmpl.Execute(w, nil)
}

func LoginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")

		var hashedPassword string
		err := db.QueryRow("SELECT password FROM users WHERE username=$1", username).Scan(&hashedPassword)
		if err != nil {
			http.Error(w, "Invalid username or password.", 400)
			log.Printf("Error fetching user: %v", err)
			return
		}

		err = bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
		if err != nil {
			http.Error(w, "Invalid username or password.", 400)
			log.Printf("Error comparing passwords: %v", err)
			return
		}

		session, err := store.Get(r, "session")
		if err != nil {
			http.Error(w, "Server error, unable to create session.", 500)
			log.Printf("Error getting session: %v", err)
			return
		}
		session.Values["authenticated"] = true
		err = session.Save(r, w)
		if err != nil {
			http.Error(w, "Server error, unable to save session.", 500)
			log.Printf("Error saving session: %v", err)
			return
		}

		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	tmpl, err := template.ParseFiles("web/login.html")
	if err != nil {
		http.Error(w, "Server error, unable to load page.", 500)
		log.Printf("Error parsing template: %v", err)
		return
	}
	tmpl.Execute(w, nil)
}

func HomeHandler(w http.ResponseWriter, r *http.Request) {
	session, err := store.Get(r, "session")
	if err != nil {
		http.Error(w, "Server error, unable to get session.", 500)
		log.Printf("Error getting session: %v", err)
		return
	}
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}
	http.Redirect(w, r, "http://localhost:8082/rooms", http.StatusSeeOther)
}
