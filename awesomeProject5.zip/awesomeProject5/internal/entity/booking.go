package entity

type Booking struct {
	ID       int
	UserID   int
	HotelID  int
	CheckIn  string
	CheckOut string
	Status   string
}
