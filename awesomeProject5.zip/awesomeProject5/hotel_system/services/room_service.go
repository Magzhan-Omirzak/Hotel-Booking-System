package services

import (
	"hotel_system/config"
	"hotel_system/models"
)

type RoomService struct{}

func (service *RoomService) CreateRoom(room *models.Room) error {
	return config.DB.Create(room).Error
}

func (service *RoomService) GetRoom(id uint) (models.Room, error) {
	var room models.Room
	err := config.DB.First(&room, id).Error
	return room, err
}

func (service *RoomService) UpdateRoom(room *models.Room) error {
	return config.DB.Save(room).Error
}

func (service *RoomService) DeleteRoom(id uint) error {
	return config.DB.Delete(&models.Room{}, id).Error
}

func (service *RoomService) GetRooms(filter map[string]interface{}, sort string, page, size int) ([]models.Room, error) {
	var rooms []models.Room
	query := config.DB.Model(&models.Room{})

	for key, value := range filter {
		query = query.Where(key+" = ?", value)
	}

	if sort != "" {
		query = query.Order(sort)
	}

	offset := (page - 1) * size
	query = query.Offset(offset).Limit(size)

	err := query.Find(&rooms).Error
	return rooms, err
}
