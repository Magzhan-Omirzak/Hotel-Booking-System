// pkg/hotel/router/router.go
package router

import (
	"awesomeProject5/pkg/hotel/handler"
	"database/sql"
	"github.com/gorilla/mux"
)

func SetupRoutes(r *mux.Router, db *sql.DB) {
	h := handler.NewHandler(db)
	r.HandleFunc("/hotels", h.GetHotels).Methods("GET")
	r.HandleFunc("/hotels", h.CreateHotel).Methods("POST")
	r.HandleFunc("/bookings", h.GetBookings).Methods("GET")
	r.HandleFunc("/bookings/{id}", h.UpdateBooking).Methods("PUT")
}
