package router

import (
	"finalfinal/auth-service/handler"
	"github.com/gorilla/mux"
)

func SetupRouter() *mux.Router {
	r := mux.NewRouter()
	r.HandleFunc("/register", handler.RegisterHandler).Methods("GET", "POST")
	r.HandleFunc("/login", handler.LoginHandler).Methods("GET", "POST")
	r.HandleFunc("/", handler.HomeHandler).Methods("GET")
	return r
}
