package main

import (
	"database/sql"
	"log"
	"net/http"
	"os"
	"time"

	_ "github.com/lib/pq"
	"room-service/handler"
	"room-service/router"
)

func main() {
	dbHost := os.Getenv("DB_HOST")
	dbPort := os.Getenv("DB_PORT")
	dbUser := os.Getenv("DB_USER")
	dbPassword := os.Getenv("DB_PASSWORD")
	dbName := os.Getenv("DB_NAME")

	connStr := "postgres://" + dbUser + ":" + dbPassword + "@" + dbHost + ":" + dbPort + "/" + dbName + "?sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal("Error connecting to the database: ", err)
	}

	for {
		err = db.Ping()
		if err == nil {
			break
		}
		log.Println("Waiting for the database to be ready...")
		time.Sleep(2 * time.Second)
	}

	h := &handler.Handler{DB: db}
	r := router.NewRouter(h)

	log.Println("Room service is running on port 8081")
	log.Fatal(http.ListenAndServe(":8081", r))
}
