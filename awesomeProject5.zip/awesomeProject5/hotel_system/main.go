package main

import (
	"hotel_system/services"
	"log"
	"net"

	"hotel_system/config"
	"hotel_system/controllers"
	"hotel_system/grpc"
	"hotel_system/models"
	"hotel_system/utils"

	"github.com/gin-gonic/gin"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

func main() {
	config.ConnectDatabase()
	config.DB.AutoMigrate(&models.Room{})

	// Initialize Gin
	r := gin.Default()

	// Define routes
	r.POST("/rooms", controllers.CreateRoom)
	r.GET("/rooms/:id", controllers.GetRoom)
	r.PUT("/rooms/:id", controllers.UpdateRoom)
	r.DELETE("/rooms/:id", controllers.DeleteRoom)
	r.GET("/rooms", controllers.GetRooms)

	// Start Gin server
	go func() {
		if err := r.Run(); err != nil {
			log.Fatalf("Failed to run HTTP server: %v", err)
		}
	}()

	// Initialize gRPC server
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("Failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	roomServiceServer := &grpc.RoomServiceServer{RoomService: &services.RoomService{}}
	grpc.RegisterRoomServiceServer(grpcServer, roomServiceServer)

	// Register reflection service on gRPC server.
	reflection.Register(grpcServer)

	utils.Logger.Info("Starting gRPC server on port :50051")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("Failed to serve gRPC server: %v", err)
	}
}
