package main

import (
	"awesomeProject5/pkg/hotel/config"
	"awesomeProject5/pkg/hotel/router"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func main() {
	r := mux.NewRouter()
	db := config.ConnectDB()
	router.SetupRoutes(r, db)

	log.Println("Hotel Service is running on port 8083")
	http.ListenAndServe(":8083", r)
}
