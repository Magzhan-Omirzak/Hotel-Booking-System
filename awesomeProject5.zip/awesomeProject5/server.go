package main

import (
	"log"
	"net/http"
)

func main() {
	fs := http.FileServer(http.Dir("./web"))
	http.Handle("/", fs)

	log.Println("Serving on :8084")
	log.Fatal(http.ListenAndServe(":8084", nil))
}
