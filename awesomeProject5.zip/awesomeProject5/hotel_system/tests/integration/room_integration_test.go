package integration

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"hotel_system/controllers"
	"hotel_system/models"
)

func TestCreateRoomIntegration(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.Default()
	r.POST("/rooms", controllers.CreateRoom)

	room := models.Room{
		Number:       "102",
		Type:         "Double",
		Price:        150.0,
		Availability: true,
	}
	roomJSON, _ := json.Marshal(room)

	req, _ := http.NewRequest(http.MethodPost, "/rooms", bytes.NewBuffer(roomJSON))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusCreated, w.Code)
}

func TestGetRoomIntegration(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.Default()
	r.GET("/rooms/:id", controllers.GetRoom)

	req, _ := http.NewRequest(http.MethodGet, "/rooms/1", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
}
